import json
import os
import requests
from urllib.parse import unquote

def lambda_handler(event, context):
    try:
        # Parse query parameters
        query_params = event.get('queryStringParameters', {})
        
        # Get coordinates string and split into pairs
        coords_str = unquote(query_params.get('coordinates', ''))
        coord_pairs = coords_str.split('|') if coords_str else []
        
        # Validate we have exactly 2 coordinate pairs
        if len(coord_pairs) != 2:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Exactly 2 coordinate pairs required in format "lat1,lon1|lat2,lon2"'})
            }
        
        weather_reports = []
        api_key =os.getenv('OPENWEATHER_API_KEY')
        #api_key = '3ad83ef7501ff2cbaeb5b8413d232a9c'
        for i, pair in enumerate(coord_pairs):
            try:
                # Split into lat/lon and validate
                lat_str, lon_str = pair.split(',')
                lat = float(lat_str)
                lon = float(lon_str)
                
                if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
                    raise ValueError("Invalid coordinate range")
                
                # Get weather data
                url = f"https://api.openweathermap.org/data/3.0/onecall?lat={lat}&lon={lon}&exclude=minutely,daily&appid={api_key}"
                response = requests.get(url)
                data = response.json()
                
                weather_reports.append(data)

                
            except ValueError as e:
                weather_reports.append({
                    'coordinate_pair': pair,
                    'error': f'Invalid coordinates: {str(e)}'
                })
            except Exception as e:
                weather_reports.append({
                    'coordinate_pair': pair,
                    'error': f'Failed to get weather data: {str(e)}'
                })
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'duration': float(query_params.get('duration', 0)),
                'weather_reports': weather_reports
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': f'Server error: {str(e)}'})
        }
    

if __name__ == "__main__":
    mock_event = {
        'queryStringParameters': {
            'coordinates': '-25.8535,28.1922|34.0522,-118.2437',  # NYC and LA coordinates
            'duration': '5.5'
        }
    }
    
    result=lambda_handler(mock_event, "")
    print(json.dumps(result, indent=2))