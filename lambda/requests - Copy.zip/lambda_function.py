import json
import requests

def lambda_handler(event, context):
    # Step 1: Extract prompt and coordinates from the request body
    try:
        body = event.get('body', {})
        prompt = body.get('prompt', '')
        coordinates = body.get('coordinates', '')
        
        if not prompt or not coordinates:
            raise ValueError("Missing required fields in request body")
            
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }
    
    # Step 2: Create headers for the request
    headers = {
        'Content-Type': 'application/json',
        'X-Api-Key': '3ad83ef7501ff2cbaeb5b8413d232a9c' # Replace with your actual API key
    }
    print(prompt+' '+ coordinates)
    # Prepare the request payload
    payload = {
        'prompt': prompt+' '+ coordinates,
    }
    
    try:
        # Step 3: Call the API endpoint
        response = requests.post(
            'https://api.openweathermap.org/assistant/session',
            headers=headers,
            json=payload
        )
        
        # Step 4: Get and return the response
        return {
            'statusCode': response.status_code,
            'body': response.text,
            'headers': {
                'Content-Type': 'application/json'
            }
        }
        
    except requests.exceptions.RequestException as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

# if __name__ == "__main__":

#     mockevent ={ 'body': {
#         'prompt': 'What’s weather along these two place? ', 
#         'coordinates': 'Pretoria and Johannesburg'
#      }
#     }
    
#     result=lambda_handler(mockevent, "")
#     print(json.dumps(result, indent=2))

